import FormInvoiceSingle from "./FormInvoiceSingle"

function FormInvoice() {
    const table = JSON.parse(localStorage.getItem("table"));
    console.log("child table", table)
    return (
        <div>
            <div className="Download-PDF">
            <button className="Download-PDF-btn"><i className="fas fa-file-pdf"></i>Download PDF</button>
            </div>
            <h1>Product Details</h1>
            {table && table.length ? table.map((data, index) => 
            <FormInvoiceSingle key={index} data={data} />
            ) :
                'No Data Found'
            }

            
        </div>
    )
}

export default FormInvoice
